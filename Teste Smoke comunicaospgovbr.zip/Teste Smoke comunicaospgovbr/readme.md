# Automação de Testes com Playwright

Este projeto realiza a automação de testes para a página da Secretaria da Cultura do Estado de São Paulo. Os testes incluem a validação de banners, notícias em destaque e o botão "Mais notícias". Além disso, são tirados screenshots das páginas para documentação visual.

## Pré-requisitos

Antes de começar, certifique-se de ter o seguinte instalado em sua máquina:

- [Node.js](https://nodejs.org/) (versão 16 ou superior)
- [npm](https://www.npmjs.com/) (geralmente vem com o Node.js)

## Instalação

1. Clone o repositório:

   ```bash
   git clone https://github.com/seu-usuario/seu-repositorio.git
   cd seu-repositorio
2. Instale as dependências do projeto:
npm install
Configuração
O arquivo playwright.config.ts contém as configurações globais para os testes. As principais configurações incluem:

testDir: Pasta onde estão os testes (./tests).

timeout: Tempo limite global para os testes (30 segundos).

retries: Número de tentativas em caso de falha (1).

use: Configurações de execução, como modo headless, tamanho da janela e política de screenshots.
Executando os Testes
Para executar todos os testes, use o seguinte comando:
npx playwright test
Executando Testes Específicos
Se você quiser executar um teste específico, pode usar o seguinte comando:
npx playwright test nome-do-arquivo-de-teste.spec.js
Executando em Modo Headless
Por padrão, os testes são executados em modo headless (sem interface gráfica). Para executar os testes com a interface gráfica, altere a configuração headless para false no arquivo playwright.config.ts.

Estrutura dos Testes
Os testes estão organizados da seguinte forma:

Testes da página da Secretaria da Cultura:

Abrir página e tirar printscreen: Tira um screenshot da página inteira.

Validar banners: Verifica se os banners estão presentes na página.

Validar notícias em destaque: Valida a notícia principal e as notícias secundárias.

Validar botão "Mais notícias": Verifica se o botão "Mais notícias" está presente e se o link está correto.

Screenshots
Os screenshots são salvos na pasta screenshots com um timestamp no nome do arquivo para facilitar a identificação. Eles são tirados em cada teste para documentar o estado da página durante a execução.

Relatórios
Após a execução dos testes, um relatório HTML é gerado automaticamente. Para visualizar o relatório, execute:
npx playwright show-report
Contribuição
Se você deseja contribuir para este projeto, siga os passos abaixo:

Faça um fork do repositório.

Crie uma branch para sua feature (git checkout -b feature/nova-feature).

Commit suas mudanças (git commit -m 'Adicionando nova feature').

Faça push para a branch (git push origin feature/nova-feature).

Abra um Pull Request.

Licença
Este projeto está licenciado sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

### Explicação do Conteúdo:

1. **Título e Descrição**: Introdução ao projeto e o que ele faz.
2. **Pré-requisitos**: Lista de softwares necessários para rodar o projeto.
3. **Instalação**: Passos para clonar o repositório e instalar as dependências.
4. **Configuração**: Explicação das configurações principais no `playwright.config.ts`.
5. **Executando os Testes**: Comandos para rodar os testes, incluindo como rodar testes específicos e em modo headless.
6. **Estrutura dos Testes**: Descrição dos testes que estão sendo realizados.
7. **Screenshots**: Explicação de como os screenshots são gerados e onde são salvos.
8. **Relatórios**: Como visualizar os relatórios de teste.
9. **Contribuição**: Instruções para contribuir com o projeto.
10. **Licença**: Informação sobre a licença do projeto.

Este `README.md` deve ser suficiente para que qualquer pessoa que queira usar ou contribuir com o projeto possa entender como ele funciona e como executar os testes.