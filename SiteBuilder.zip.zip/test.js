const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  try {
    // Acessa a página de login
    await page.goto('https://adminsggd.des.sp.gov.br/!ut/p/z0/04_Sj9CPykssy0xPLMnMz0vMAfIj8nKt8jNTrMoLivV88tMz8_QLsh0VAZSk7Xs!/');

    // Faz login
    await page.fill('input#userID', '34011540870');
    await page.fill('input#password', 'prodesp');
    await page.click('button#login\\.button\\.login');
    await page.waitForNavigation({ waitUntil: 'networkidle' });

    // Acessa a página após o login
    await page.goto('https://adminsggd.des.sp.gov.br/usuario/teste_Simone/');

    // Abre o menu "Institucional"
    await page.waitForSelector('#Institucional', { timeout: 15000 });
    await page.click('#Institucional');

    // Aguarda a subopção aparecer
    await page.waitForSelector('.dropdown-item a', { timeout: 15000 });

    // Obtém todas as subopções do menu
    let subOptions = await page.$$('.dropdown-item a');

    for (let i = 0; i < subOptions.length; i++) {
      const subOptionText = await subOptions[i].innerText();
      console.log(`Interagindo com: ${subOptionText}`);

      // Força o clique na opção do menu
      await subOptions[i].click({ force: true });

      // Aguarda a navegação acontecer
      try {
        await page.waitForNavigation({ waitUntil: 'networkidle', timeout: 10000 });
      } catch (error) {
        console.log(`A opção "${subOptionText}" não redirecionou para outra página.`);
      }

      // Tira um screenshot da página carregada
      await page.screenshot({ path: `screenshot_${i + 1}.png`, fullPage: true });

      // Volta para a página anterior
      await page.goBack();
      await page.waitForTimeout(1000);

      // Reabre o menu para continuar a interação
      await page.click('#Institucional');
      await page.waitForSelector('.dropdown-item a', { timeout: 15000 });

      // Atualiza a lista de opções do menu
      subOptions = await page.$$('.dropdown-item a');
    }
  } catch (error) {
    console.error('Erro durante a execução:', error);
  } finally {
    await browser.close();
  }
})();
