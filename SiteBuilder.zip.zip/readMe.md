# Automação de Testes com Playwright

Este repositório contém scripts de automação de testes utilizando o [Playwright](https://playwright.dev/), uma ferramenta de automação de navegadores. Os scripts foram desenvolvidos para interagir com uma aplicação web específica, realizando login, navegando por menus e capturando screenshots das páginas acessadas.

## Scripts Disponíveis

### `test.js`

Este script realiza as seguintes ações:

1. **Login na aplicação**: Acessa a página de login e preenche as credenciais.
2. **Navegação no menu "Institucional"**: Abre o menu "Institucional" e interage com todas as subopções disponíveis.
3. **Captura de screenshots**: Para cada subopção, tira um screenshot da página carregada.
4. **Volta à página anterior**: Após cada interação, volta à página anterior para continuar o processo.

### `testcanais.js`

Este script realiza as seguintes ações:

1. **Login na aplicação**: Acessa a página de login e preenche as credenciais.
2. **Navegação no menu "Canais de Comunicação"**: Abre o menu "Canais de Comunicação" e interage com todos os itens do menu suspenso.
3. **Abertura de links em novas abas**: Para cada item do menu, abre o link correspondente em uma nova aba e captura um screenshot da página carregada.
4. **Fechamento de abas**: Fecha a aba após a captura do screenshot.

### `testfooter.js`

Este script realiza as seguintes ações:

1. **Login na aplicação**: Acessa a página de login e preenche as credenciais.
2. **Interação com cards**: Navega por um carrossel de cards, clicando em cada um e abrindo o link correspondente em uma nova aba.
3. **Verificação de links válidos**: Verifica se cada card possui um link válido antes de interagir com ele.
4. **Fechamento de abas**: Fecha a aba após a verificação do link.

## Pré-requisitos

- Node.js instalado na máquina.
- Playwright instalado. Para instalar, execute o seguinte comando:

  ```bash
  npm install playwright

  Como Executar os Scripts
Clone este repositório ou copie os scripts para o seu ambiente local.

Navegue até o diretório onde os scripts estão localizados.

Execute um dos scripts utilizando o Node.js. Por exemplo:
node test.js

Ou:
node testcanais.js

OU
node testfooter.js

Licença
Este projeto está licenciado sob a licença MIT. Consulte o arquivo LICENSE para mais detalhes.


### Como usar o `README.md`

1. Crie um arquivo chamado `README.md` no mesmo diretório onde estão os scripts.
2. Copie e cole o conteúdo acima no arquivo `README.md`.
3. Personalize o conteúdo conforme necessário, como adicionar informações específicas sobre o projeto ou ajustar as instruções de execução.

Esse arquivo `README.md` servirá como documentação para quem for utilizar ou contribuir com os scripts.