const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  try {
    // Acessa a página de login
    await page.goto('https://adminsggd.des.sp.gov.br/!ut/p/z0/04_Sj9CPykssy0xPLMnMz0vMAfIj8nKt8jNTrMoLivV88tMz8_QLsh0VAZSk7Xs!/', { waitUntil: 'networkidle' });

    // Faz login
    await page.fill('input#userID', '34011540870');
    await page.fill('input#password', 'prodesp');
    await page.click('button#login\\.button\\.login');
    await page.waitForNavigation({ waitUntil: 'networkidle' });

    // Acessa a página após o login
    await page.goto('https://adminsggd.des.sp.gov.br/usuario/teste_Simone/', { waitUntil: 'domcontentloaded' });

    // Aguarda e abre o menu "Canais de Comunicação"
    await page.waitForSelector('#Canais\\ de\\ comunicação', { timeout: 20000 });
    await page.hover('#Canais\\ de\\ comunicação');  
    await page.click('#Canais\\ de\\ comunicação');  
    await page.waitForTimeout(2000); 

    // Aguarda e coleta os itens do menu suspenso
    let menuItems = await page.$$('.dropdown-item a');

    console.log(`Foram encontrados ${menuItems.length} itens no menu.`);

    for (let i = 0; i < menuItems.length; i++) {
      const itemText = await menuItems[i].innerText();
      let href = await menuItems[i].getAttribute('href');

      console.log(`Interagindo com: ${itemText}`);

      // Se o link for relativo, converte para absoluto
      if (href && !href.startsWith('http')) {
        href = 'https://adminsggd.des.sp.gov.br' + href;
      }

      if (href) {
        console.log(`Abrindo link: ${href}`);

        // Abre o link em uma nova aba
        const newPage = await context.newPage();
        await newPage.goto(href, { waitUntil: 'domcontentloaded' });

        // Tira um screenshot da página carregada
        await newPage.screenshot({ path: `screenshot_${i + 1}.png`, fullPage: true });

        // Fecha a aba
        await newPage.close();
      } else {
        console.log(`O item '${itemText}' não tem um link válido.`);
      }
    }

    console.log('Teste finalizado.');
  } catch (error) {
    console.error('Erro durante a execução:', error);
  } finally {
    await browser.close();
  }
})();
