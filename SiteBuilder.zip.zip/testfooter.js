const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  try {
    // Acessa a página de login
    await page.goto('https://adminsggd.des.sp.gov.br/!ut/p/z0/04_Sj9CPykssy0xPLMnMz0vMAfIj8nKt8jNTrMoLivV88tMz8_QLsh0VAZSk7Xs!/');

    // Faz login
    await page.fill('input#userID', '34011540870');
    await page.fill('input#password', 'prodesp');
    await page.click('button#login\\.button\\.login');
    await page.waitForNavigation({ waitUntil: 'networkidle' });

    // Acessa a página com os cards
    await page.goto('https://adminsggd.des.sp.gov.br/usuario/teste_Simone/');

    // Aguarda os cards carregarem
    await page.waitForSelector('.slick-slide a', { timeout: 15000 });

    let index = 0;
    let maxAttempts = 10; // Evita loop infinito
    let attempts = 0;

    while (attempts < maxAttempts) {
      // Seleciona o card ativo
      const activeCard = await page.$('.slick-slide.slick-current.slick-active');

      if (activeCard) {
        // Obtém o link do card
        const linkElement = await activeCard.$('a');
        if (linkElement) {
          let href = await linkElement.getAttribute('href');

          if (href && href.trim() !== '') {
            console.log(`Clicando no card ${index}: ${href}`);

            // Abre o link em uma nova aba
            const newPage = await context.newPage();
            await newPage.goto(href, { waitUntil: 'domcontentloaded' });

            // Fecha a aba depois de verificar que a página abriu
            await newPage.waitForTimeout(3000);
            await newPage.close();
          } else {
            console.warn(`⚠️ Atenção: O card ${index} não possui um link válido! Pulando...`);
          }
        }
      }

      // Clica no botão "Próximo" para mudar o card
      const nextButton = await page.$('.slick-next');
      if (nextButton) {
        await nextButton.click();
        await page.waitForTimeout(1000); // Pequeno delay para animação do carrossel
      } else {
        console.log('Botão "Próximo" não encontrado, saindo do loop.');
        break;
      }

      index++;
      attempts++;
    }

    console.log('Teste finalizado.');
  } catch (error) {
    console.error('Erro durante a execução:', error);
  } finally {
    await browser.close();
  }
})();
