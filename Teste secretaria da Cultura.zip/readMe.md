Testes Automatizados para a Secretaria da Cultura de SP
Este repositório contém um conjunto de testes automatizados desenvolvidos para validar a funcionalidade e a integridade das páginas da Secretaria da Cultura do Estado de São Paulo. Através deste projeto, foram identificados diversos erros nas páginas, incluindo imagens que não carregam, links quebrados e problemas de interação com elementos da página.

O objetivo principal é garantir que a experiência do usuário seja a melhor possível, identificando e relatando problemas que possam prejudicar a navegação ou a acessibilidade do site.

Como Funciona o Teste
O teste foi desenvolvido utilizando a ferramenta Playwright, que permite automatizar a interação com páginas web em diferentes navegadores. O script realiza as seguintes ações:

Navega até a página da Secretaria da Cultura:

Acessa a URL https://www.cultura.sp.gov.br/sec_cultura.

Aguarda o carregamento completo da página.

Verifica as imagens:

Confirma que todas as imagens estão carregando corretamente.

Verifica se as imagens possuem o atributo alt (importante para acessibilidade).

Valida os links:

Testa todos os links da página para garantir que estão funcionando.

Relata links quebrados ou inacessíveis.

Interage com elementos da página:

Clica no botão "Next" (se disponível) para garantir que a interação funciona corretamente.

Gera relatórios e screenshots:

Captura screenshots da página para análise manual.

Gera um relatório HTML com os resultados dos testes.

Erros Encontrados
Durante a execução dos testes, foram identificados os seguintes problemas:

Imagens sem atributo alt: Algumas imagens não possuem o atributo alt, o que pode prejudicar a acessibilidade para usuários com deficiência visual.

Links quebrados: Diversos links retornaram erros ao serem acessados, como status 404 ou falhas na requisição.

Problemas de interação: Em alguns casos, elementos interativos (como o botão "Next") não funcionaram conforme o esperado.

Esses problemas foram registrados no console durante a execução dos testes e também estão disponíveis no relatório HTML gerado.

Como Executar o Teste
Pré-requisitos
Node.js instalado (versão 16 ou superior).

Playwright instalado globalmente ou como dependência do projeto.

Passos para Execução

1. Clone este repositório:

git clone https://github.com/seu-usuario/seu-repositorio.git
cd seu-repositorio

2. Instale as dependências:

npm install

3. Execute os testes:



npx playwright test


4. Visualize o relatório:
Após a execução, um relatório HTML será gerado. Para visualizá-lo, execute:

npx playwright show-report

Estrutura do Projeto
tests/: Contém o arquivo de teste principal (culturaSP.spec.js).

screenshots/: Diretório onde os screenshots das páginas testadas são salvos.

playwright.config.ts: Configurações do Playwright, incluindo navegadores e opções de execução.

Contribuições
Se você encontrou algum problema ou tem sugestões para melhorar os testes, sinta-se à vontade para abrir uma issue ou enviar um pull request. Sua contribuição é muito bem-vinda!

Agradecimentos
Este projeto foi desenvolvido com o intuito de contribuir para a melhoria contínua dos serviços digitais da Secretaria da Cultura. Agradeço a todos que colaboraram direta ou indiretamente para a realização deste trabalho.



