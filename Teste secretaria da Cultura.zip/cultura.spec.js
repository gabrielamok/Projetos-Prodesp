const { test, expect } = require('@playwright/test');
const fs = require('fs');
const path = require('path');

// Função para garantir que o diretório de screenshots exista
const ensureScreenshotsDirExists = () => {
  const screenshotsDir = path.join(__dirname, 'screenshots');
  if (!fs.existsSync(screenshotsDir)) {
    fs.mkdirSync(screenshotsDir, { recursive: true });
    console.log(`Diretório de screenshots criado: ${screenshotsDir}`);
  }
};

test.describe('Cultura SP Page Validation', () => {
  test('should validate images, links, and interact with the page', async ({ browser }) => {
    // Aumenta o timeout do teste para 60 segundos
    test.setTimeout(60000);

    // Garante que o diretório de screenshots exista
    ensureScreenshotsDirExists();

    // Abre o navegador em modo não headless (para visualização)
    const context = await browser.newContext({
      viewport: { width: 1280, height: 720 }, // Define o tamanho da janela
    });
    const page = await context.newPage();

    try {
      console.log('Navegando até a página...');
      await page.goto('https://www.cultura.sp.gov.br/sec_cultura', { waitUntil: 'domcontentloaded' });
      console.log('Página carregada.');

      // Aguarda até que todas as requisições sejam concluídas
      console.log('Aguardando carregamento completo da página...');
      await page.waitForLoadState('networkidle');
      console.log('Página totalmente carregada.');

      // Verifica se as imagens estão carregando corretamente
      console.log('Verificando imagens...');
      const images = await page.$$eval('img', imgs =>
        imgs.map(img => ({
          src: img.src,
          naturalWidth: img.naturalWidth,
          alt: img.alt
        }))
      );

      for (const img of images) {
        if (!img.src.endsWith('.svg')) { // Ignora SVGs
          expect(img.naturalWidth).toBeGreaterThan(0); // Verifica se a imagem foi carregada
        }

        // Verifica se o atributo alt está presente (opcional, apenas para imagens não decorativas)
        if (!img.alt) {
          console.warn(`Imagem sem atributo alt: ${img.src}`);
        }
      }

      // Verifica se os links estão funcionando sem navegar
      console.log('Verificando links...');
      const links = await page.$$eval('a[href]', links => links.map(link => link.href));
      const brokenLinks = [];

      for (const link of links) {
        if (!link.startsWith('javascript:') && !link.startsWith('#')) { // Ignora links inválidos
          try {
            const response = await page.request.get(link);
            if (response.status() >= 400) {
              brokenLinks.push({ link, status: response.status() });
            }
          } catch (error) {
            brokenLinks.push({ link, status: 'Erro ao acessar o link' });
          }
        }
      }

      // Exibe os links quebrados no relatório
      if (brokenLinks.length > 0) {
        console.warn('Links quebrados encontrados:');
        brokenLinks.forEach(({ link, status }) => {
          console.warn(`- Link: ${link}, Status: ${status}`);
        });
      } else {
        console.log('Nenhum link quebrado encontrado.');
      }

      // Interage com o botão "Next" (se existir)
      console.log('Interagindo com o botão "Next"...');
      const nextButton = await page.$('.slick-next');
      if (nextButton) {
        await nextButton.click();
        await page.waitForTimeout(1000); // Aguarda 1 segundo para garantir que a ação seja concluída
        console.log('Botão "Next" clicado com sucesso.');
      } else {
        console.warn('Botão "Next" não encontrado na página.');
      }
    } catch (error) {
      console.error(`Erro durante a execução do teste: ${error.message}`);
    } finally {
      // Gera um screenshot para verificação manual, independentemente de erros
      console.log('Gerando screenshot...');
      const date = new Date();
      const timestamp = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}_${date.getHours()}-${date.getMinutes()}-${date.getSeconds()}`;
      const screenshotPath = path.join(__dirname, 'screenshots', `culturaSP_${timestamp}.png`);
      await page.screenshot({ path: screenshotPath, fullPage: true });
      console.log(`Screenshot salvo em: ${screenshotPath}`);

      // Mantém o navegador aberto para inspeção manual (opcional)
      console.log('Teste pausado para inspeção manual. Pressione F8 para continuar.');
      await page.pause(); // Pausa a execução do teste para inspeção manual

      // Fecha o navegador após o teste (comente esta linha se quiser manter o navegador aberto)
      await context.close();
    }
  });
});