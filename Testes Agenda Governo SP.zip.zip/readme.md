# Testes de Validação de Data Atual na Agenda do Governador com Playwright

Este projeto utiliza o [Playwright](https://playwright.dev/) para automatizar testes de validação da data atual na agenda do governador do estado de São Paulo. O objetivo é garantir que a data exibida na página corresponde à data atual, tanto em dispositivos desktop quanto mobile.

## 🛠️ Pré-requisitos

Antes de começar, certifique-se de ter o seguinte instalado:

- [Node.js](https://nodejs.org/) (versão 16 ou superior)
- [npm](https://www.npmjs.com/) ou [Yarn](https://yarnpkg.com/) (gerenciadores de pacotes)

## 🚀 Configuração do Projeto

1. **Clone o repositório**:
   ```bash
   git clone https://github.com/seu-usuario/nome-do-repositorio.git
   cd nome-do-repositorio
2. Instale as dependências:
    npm install
3. Configuração do Playwright:
O arquivo playwright.config.ts já está configurado para executar testes em dois ambientes:

Desktop Chromium: Simula um navegador desktop.

Mobile Chrome: Simula um iPhone 12 Pro.

Você pode ajustar as configurações no arquivo playwright.config.ts conforme necessário.

🧪 Executando os Testes
Para executar todos os testes, utilize o seguinte comando:
npx playwright test

Executando Testes Específicos
Teste no Desktop Chromium:
npx playwright test --project=chromium

Teste no Mobile Chrome:
npx playwright test --project=mobile

npx playwright test --project=mobile

Modo de Depuração
Para visualizar a execução dos testes no navegador (modo não headless), o Playwright já está configurado para manter o navegador visível. Caso queira desativar, altere a opção headless: false para true no arquivo playwright.config.ts.

📊 Relatórios
Os testes geram relatórios no formato Allure. Para visualizar o relatório após a execução dos testes, utilize o seguinte comando:

npx allure serve ./test-results

Isso abrirá o relatório no seu navegador padrão.

📂 Estrutura do Projeto
tests/: Contém os arquivos de teste.

example.spec.ts: Teste de validação da data atual na agenda do governador.

playwright.config.ts: Configurações do Playwright, incluindo dispositivos e navegadores.

test-results/: Armazena os resultados dos testes e screenshots.

📸 Screenshots
Durante a execução dos testes, screenshots são capturados automaticamente em caso de sucesso ou falha. Eles são salvos na pasta test-results com o nome no formato:

🤔 Como Funciona o Teste?
O teste realiza as seguintes etapas:

Acessa a página da agenda do governador.

Verifica se o campo de data está visível.

Clica no campo de data e seleciona a data atual no calendário.

Compara a data exibida na página com a data atual do sistema.

Gera um screenshot da tela para fins de documentação.

📝 Observações
O teste foi configurado para simular um iPhone 12 Pro no modo mobile.

O tempo limite (timeout) para carregamento de elementos e páginas foi ajustado para evitar falhas devido a lentidão na rede.

📄 Licença
Este projeto está licenciado sob a licença MIT. Consulte o arquivo LICENSE para mais detalhes.
