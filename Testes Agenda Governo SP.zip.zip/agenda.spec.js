import { test, expect, devices } from '@playwright/test';

test.use({ headless: false }); // Mantém o navegador visível para depuração

test.describe('Validar data atual na agenda do governador', () => {
  
  async function validarDataAtual(page, deviceType) {
    // Configura o viewport para garantir que a página seja exibida corretamente
    await page.setViewportSize({ width: 1280, height: 800 }); // Tamanho padrão para desktop
    if (deviceType === 'mobile') {
      await page.setViewportSize({ width: 390, height: 844 }); // Tamanho para iPhone 12 Pro
    }

    await page.goto('https://sp.gov.br/sp/institucional/agenda_governador', { waitUntil: 'domcontentloaded', timeout: 120000 });

    // Aguarda a presença do input de data
    const inputLocator = page.locator('[data-input="data-input"]');

    try {
      // Tenta esperar pelo elemento ficar visível
      await inputLocator.waitFor({ state: 'visible', timeout: 20000 }); // 20 segundos
      console.log('Input de data está visível.');

      await inputLocator.scrollIntoViewIfNeeded();
      await inputLocator.click();

      console.log('Input de data clicado.');

      // Aguarda a data atual no calendário e seleciona
      await page.waitForSelector('.flatpickr-day.today', { timeout: 60000 });
      await page.locator('.flatpickr-day.today').click();

      console.log('Data atual selecionada no calendário.');

      // Aguarda a atualização do sistema
      await page.waitForTimeout(2000);

      // Captura a data confirmada na página
      const dataNaPagina = await page.evaluate(() => {
        const input = document.querySelector('[data-input="data-input"]');
        return input ? input.value : null;
      });

      console.log(`Data na página: ${dataNaPagina}`);

      // Compara com a data atual
      const dataAtual = new Date().toLocaleDateString('pt-BR');
      expect(dataNaPagina).toContain(dataAtual);

      console.log('Data na página é igual à data atual.');
    } catch (error) {
      console.error('Erro durante a execução do teste:', error.message);
    } finally {
      // Gera nome do arquivo com data, hora e dispositivo
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const screenshotPath = `screenshot-${deviceType}-${timestamp}.png`;

      // Captura print da tela inteira (fullscreen)
      await page.screenshot({ path: screenshotPath, fullPage: true });

      console.log(`Screenshot salvo: ${screenshotPath}`);
    }
  }

  test('Validar no Desktop Chromium', async ({ page }) => {
    await validarDataAtual(page, 'desktop');
  });

  test('Validar no Mobile Chrome', async ({ browser }) => {
    const mobileContext = await browser.newContext({
      ...devices['iPhone 12 Pro'], // Simula um iPhone 12 Pro
    });
    const mobilePage = await mobileContext.newPage();
    await validarDataAtual(mobilePage, 'mobile');
  });

});